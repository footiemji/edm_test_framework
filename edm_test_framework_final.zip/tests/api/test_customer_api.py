import pytest
import yaml

from core.config_loader import load_env
from core.api_engine import call_api
from core.schema_validator import validate_schema
from payloads.customer_payloads import new_customer_payload, update_customer_payload

@pytest.mark.api
@pytest.mark.smoke
def test_customer_post_get_put(request):
    env = request.config.getoption("--env")
    cfg = load_env(env)

    with open("configs/endpoints.yaml", "r", encoding="utf-8") as f:
        endpoints = yaml.safe_load(f)

    # POST
    create_ep = endpoints["create_customer"]
    create_payload = new_customer_payload()

    status, body, _headers = call_api(
        base_url=cfg["base_url"],
        token=cfg["token"],
        method=create_ep["method"],
        path=create_ep["path"],
        payload=create_payload,
    )

    assert status == create_ep["expected_status"]
    validate_schema(body, create_ep["schema"])

    # GET
    get_ep = endpoints["get_customer"]
    status, body, _headers = call_api(
        base_url=cfg["base_url"],
        token=cfg["token"],
        method=get_ep["method"],
        path=get_ep["path"],
    )
    assert status == get_ep["expected_status"]
    validate_schema(body, get_ep["schema"])

    # PUT
    update_ep = endpoints["update_customer"]
    update_payload = update_customer_payload()

    status, body, _headers = call_api(
        base_url=cfg["base_url"],
        token=cfg["token"],
        method=update_ep["method"],
        path=update_ep["path"],
        payload=update_payload,
    )
    assert status == update_ep["expected_status"]
    validate_schema(body, update_ep["schema"])
