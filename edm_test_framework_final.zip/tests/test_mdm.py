import pytest

@pytest.mark.mdm
def test_mdm_placeholder():
    assert True
