import requests

def call_api(
    base_url: str,
    token: str,
    method: str,
    path: str,
    payload: dict | None = None,
    path_params: dict | None = None,
    query_params: dict | None = None,
    extra_headers: dict | None = None,
    timeout_seconds: int = 30,
):
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    if extra_headers:
        headers.update(extra_headers)

    if path_params:
        path = path.format(**path_params)

    url = f"{base_url}{path}"

    resp = requests.request(
        method=method.upper(),
        url=url,
        params=query_params,
        json=payload,
        headers=headers,
        timeout=timeout_seconds,
    )

    try:
        body = resp.json()
    except Exception:
        body = resp.text

    return resp.status_code, body, resp.headers
