import pytest

@pytest.mark.metadata
def test_metadata_placeholder():
    assert True
