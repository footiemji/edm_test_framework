import pandas as pd

def read_ataccama_export(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def read_rdm_export(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def read_mdm_export(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def read_metadata_export(path: str) -> pd.DataFrame:
    return pd.read_csv(path)
