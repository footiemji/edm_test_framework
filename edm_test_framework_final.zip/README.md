# EDM Test Framework (API + DQ + RDM + MDM + Metadata)

## Quickstart (Windows)
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
pytest -m api --env=dev
```

## Reports
After a run, open:
- `test_results/report.html`

## DQ export validation (Ataccama)
1. Export DQ results from Ataccama to CSV with columns:
   - record_id, rule_name, result
2. Save as:
   - `exports/ataccama/dq_export.csv`
3. Run:
```bash
pytest -m dq
```
See `exports/ataccama/dq_export_SAMPLE.csv` for the expected format.

## RDM export validation
Save your active RDM values as:
- `exports/rdm/rdm_values.csv` with column `country_code`
Then run:
```bash
pytest -m rdm
```
