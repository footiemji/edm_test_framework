from faker import Faker

fake = Faker()

def new_customer_payload() -> dict:
    return {
        "firstName": fake.first_name(),
        "lastName": fake.last_name(),
        "email": fake.email(),
        "phone": fake.phone_number(),
    }

def update_customer_payload() -> dict:
    return {
        "firstName": fake.first_name(),
        "lastName": fake.last_name(),
    }
