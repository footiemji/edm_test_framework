import pytest
from pathlib import Path

from core.dataset_manager import load_dataset
from core.export_reader import read_rdm_export
from core.assertion_engine import validate_rdm
from core.report_builder import build_report

@pytest.mark.rdm
@pytest.mark.sanity
def test_rdm_export_validation():
    export_path = Path("exports/rdm/rdm_values.csv")
    if not export_path.exists():
        pytest.skip(
            "Missing exports/rdm/rdm_values.csv. "
            "Export active RDM values and drop it there. "
            "See exports/rdm/rdm_values_SAMPLE.csv for required columns."
        )

    dataset = load_dataset("customers_batch.csv")
    rdm = read_rdm_export(str(export_path))

    result = validate_rdm(dataset, rdm)
    build_report("RDM EXPORT VALIDATION", result)
    assert result.passed
