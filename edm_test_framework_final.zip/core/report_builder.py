def build_report(title: str, result) -> None:
    print(f"\n=== {title} ===")
    if result.passed:
        print("PASSED")
    else:
        print("FAILED")
        print(result.report)
