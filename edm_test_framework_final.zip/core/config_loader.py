import yaml

def load_env(env: str) -> dict:
    with open("configs/environments.yaml", "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if env not in data:
        raise KeyError(f"Unknown env '{env}'. Available: {list(data.keys())}")
    return data[env]
