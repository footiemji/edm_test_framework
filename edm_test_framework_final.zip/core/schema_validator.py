import json
from jsonschema import validate

def validate_schema(data: object, schema_path: str) -> None:
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = json.load(f)
    validate(instance=data, schema=schema)
