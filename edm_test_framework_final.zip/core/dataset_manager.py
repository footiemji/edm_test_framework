import pandas as pd

def load_dataset(relative_path: str) -> pd.DataFrame:
    return pd.read_csv(f"datasets/{relative_path}")
