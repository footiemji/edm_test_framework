import json

class Result:
    def __init__(self):
        self.errors: list[str] = []

    @property
    def passed(self) -> bool:
        return len(self.errors) == 0

    @property
    def report(self) -> str:
        return "\n".join(self.errors)

def load_expectations() -> dict:
    with open("expectations/expectations.json", "r", encoding="utf-8") as f:
        return json.load(f)

def validate_dq(dataset, export):
    """
    Expects Ataccama export columns:
      - record_id
      - rule_name
      - result   (PASS/FAIL)
    """
    exp = load_expectations()
    result = Result()

    for _, row in dataset.iterrows():
        rec = row["record_id"]
        if rec not in exp or "dq" not in exp[rec]:
            continue

        for rule_name, expected_outcome in exp[rec]["dq"].items():
            subset = export[(export["record_id"] == rec) & (export["rule_name"] == rule_name)]
            if subset.empty:
                result.errors.append(f"DQ missing result: record_id={rec}, rule={rule_name}")
                continue

            actual = str(subset["result"].iloc[0]).strip()
            if actual != expected_outcome:
                result.errors.append(
                    f"DQ mismatch: record_id={rec}, rule={rule_name}, expected={expected_outcome}, got={actual}"
                )

    return result

def validate_rdm(dataset, rdm_export):
    """
    Expects RDM export includes at least:
      - country_code
    """
    exp = load_expectations()
    result = Result()

    valid_codes = set(rdm_export["country_code"].astype(str))

    for _, row in dataset.iterrows():
        rec = row["record_id"]
        if rec not in exp or "rdm" not in exp[rec]:
            continue

        code = str(row["country_code"])
        expected = exp[rec]["rdm"].get("country_code")

        if expected == "VALID" and code not in valid_codes:
            result.errors.append(f"RDM invalid: record_id={rec}, country_code={code} not in RDM list")

        if expected == "INVALID" and code in valid_codes:
            result.errors.append(f"RDM invalid: record_id={rec}, country_code={code} SHOULD be invalid but exists")

    return result
