import pytest
from pathlib import Path

from core.dataset_manager import load_dataset
from core.export_reader import read_ataccama_export
from core.assertion_engine import validate_dq
from core.report_builder import build_report

@pytest.mark.dq
@pytest.mark.regression
def test_dq_export_validation():
    export_path = Path("exports/ataccama/dq_export.csv")
    if not export_path.exists():
        pytest.skip(
            "Missing exports/ataccama/dq_export.csv. "
            "Export your DQ results from Ataccama and drop it there. "
            "See exports/ataccama/dq_export_SAMPLE.csv for required columns."
        )

    dataset = load_dataset("customers_batch.csv")
    export = read_ataccama_export(str(export_path))

    result = validate_dq(dataset, export)
    build_report("DQ EXPORT VALIDATION", result)
    assert result.passed
